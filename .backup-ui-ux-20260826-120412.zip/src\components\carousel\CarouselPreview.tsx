"use client";

import clsx from "clsx";
import { ChevronLeft, ChevronRight, LayoutGrid, Square } from "lucide-react";
import { useState } from "react";

import type { SlideThemeId } from "@/constants/themes";
import type { Slide } from "@/types/carousel";

import { CarouselSlide, type LogoConfig } from "./CarouselSlide";

const SINGLE_SCALE = 0.42;
const GRID_SCALE = 0.17;

type CarouselPreviewProps = {
  slides: Slide[];
  themeId: SlideThemeId;
  logo?: LogoConfig | null;
  activeIndex: number;
  onActiveIndexChange: (index: number) => void;
};

const iconButton =
  "flex h-9 w-9 items-center justify-center rounded-full border border-zinc-300 bg-white text-zinc-700 transition hover:border-zinc-900 disabled:opacity-30 disabled:hover:border-zinc-300";

export function CarouselPreview({
  slides,
  themeId,
  logo,
  activeIndex,
  onActiveIndexChange,
}: CarouselPreviewProps) {
  const [isGrid, setIsGrid] = useState(false);
  const activeSlide = slides[activeIndex] ?? slides[0];

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium uppercase tracking-wide text-zinc-500">
          Preview
        </span>
        <div className="flex gap-1 rounded-full border border-zinc-300 bg-white p-1">
          <button
            type="button"
            onClick={() => setIsGrid(false)}
            aria-pressed={!isGrid}
            title="Slide único"
            className={clsx(
              "flex h-7 w-7 items-center justify-center rounded-full transition",
              isGrid ? "text-zinc-500 hover:text-zinc-900" : "bg-zinc-900 text-white",
            )}
          >
            <Square size={14} />
          </button>
          <button
            type="button"
            onClick={() => setIsGrid(true)}
            aria-pressed={isGrid}
            title="Grade"
            className={clsx(
              "flex h-7 w-7 items-center justify-center rounded-full transition",
              isGrid ? "bg-zinc-900 text-white" : "text-zinc-500 hover:text-zinc-900",
            )}
          >
            <LayoutGrid size={14} />
          </button>
        </div>
      </div>

      {isGrid ? (
        <div className="flex flex-wrap gap-4">
          {slides.map((slide, index) => (
            <button
              key={slide.slideNumber}
              type="button"
              onClick={() => {
                onActiveIndexChange(index);
                setIsGrid(false);
              }}
              className={clsx(
                "rounded-md ring-offset-4 ring-offset-zinc-100 transition",
                index === activeIndex ? "ring-2 ring-zinc-900" : "hover:ring-2 hover:ring-zinc-300",
              )}
            >
              <CarouselSlide
                slide={slide}
                totalSlides={slides.length}
                themeId={themeId}
                logo={logo}
                scale={GRID_SCALE}
              />
            </button>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center gap-4">
          <CarouselSlide
            slide={activeSlide}
            totalSlides={slides.length}
            themeId={themeId}
            logo={logo}
            scale={SINGLE_SCALE}
          />
          <div className="flex items-center gap-4">
            <button
              type="button"
              className={iconButton}
              onClick={() => onActiveIndexChange(activeIndex - 1)}
              disabled={activeIndex === 0}
              aria-label="Slide anterior"
            >
              <ChevronLeft size={18} />
            </button>
            <span className="text-sm tabular-nums text-zinc-600">
              {activeIndex + 1} / {slides.length}
            </span>
            <button
              type="button"
              className={iconButton}
              onClick={() => onActiveIndexChange(activeIndex + 1)}
              disabled={activeIndex === slides.length - 1}
              aria-label="Próximo slide"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
