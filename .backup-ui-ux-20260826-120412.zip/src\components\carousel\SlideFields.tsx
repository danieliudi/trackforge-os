"use client";

import clsx from "clsx";
import { Copy, Trash2, Upload, X } from "lucide-react";
import { useId } from "react";

import type { ImageLayout, Slide } from "@/types/carousel";

const BODY_MAX = 30;

const IMAGE_LAYOUTS: { id: ImageLayout; label: string }[] = [
  { id: "background", label: "Fundo total" },
  { id: "card", label: "Card" },
  { id: "split", label: "Split" },
];

type SlideFieldsProps = {
  slide: Slide;
  isActive: boolean;
  onChange: (patch: Partial<Slide>) => void;
  onFocus: () => void;
  onDuplicate: () => void;
  onRemove: () => void;
  /** Falso quando remover quebraria o schema (capa, CTA ou mínimo de slides). */
  canRemove: boolean;
  removeBlockedReason?: string;
};

const labelClass = "text-[11px] font-medium uppercase tracking-wide text-zinc-500";
const fieldClass =
  "w-full rounded-md border border-zinc-200 bg-white px-2.5 py-2 text-sm text-zinc-900 outline-none focus:border-zinc-900";

function readAsDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("não foi possível ler o arquivo"));
    reader.readAsDataURL(file);
  });
}

export function SlideFields({
  slide,
  isActive,
  onChange,
  onFocus,
  onDuplicate,
  onRemove,
  canRemove,
  removeBlockedReason,
}: SlideFieldsProps) {
  const remaining = BODY_MAX - slide.bodyText.length;
  const uploadId = useId();
  const isUploaded = slide.image?.url.startsWith("data:") ?? false;

  function setImageUrl(url: string) {
    onChange({
      image: url
        ? { url, layout: slide.image?.layout ?? "background" }
        : undefined,
    });
  }

  async function handleUpload(file: File | undefined) {
    if (!file) return;
    setImageUrl(await readAsDataUrl(file));
  }

  return (
    <div
      onFocus={onFocus}
      className={clsx(
        "flex flex-col gap-3 rounded-lg border p-3 transition",
        isActive ? "border-zinc-900 bg-zinc-50" : "border-zinc-200 bg-white",
      )}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-semibold text-zinc-900">
          Slide {slide.slideNumber}
        </span>
        <div className="flex items-center gap-1">
          <span className="rounded bg-zinc-100 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-zinc-600">
            {slide.type}
          </span>
          <button
            type="button"
            onClick={onDuplicate}
            title="Duplicar slide"
            className="flex h-6 w-6 items-center justify-center rounded text-zinc-500 transition hover:bg-zinc-100 hover:text-zinc-900"
          >
            <Copy size={13} />
          </button>
          <button
            type="button"
            onClick={onRemove}
            disabled={!canRemove}
            title={canRemove ? "Remover slide" : removeBlockedReason}
            className="flex h-6 w-6 items-center justify-center rounded text-zinc-500 transition hover:bg-red-50 hover:text-red-600 disabled:cursor-not-allowed disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-zinc-500"
          >
            <Trash2 size={13} />
          </button>
        </div>
      </div>

      <label className="flex flex-col gap-1">
        <span className={labelClass}>Headline</span>
        <textarea
          rows={2}
          value={slide.headline}
          onChange={(event) => onChange({ headline: event.target.value })}
          className={clsx(fieldClass, "resize-y")}
        />
      </label>

      <label className="flex flex-col gap-1">
        <span className={labelClass}>
          Body text{" "}
          <span className={remaining <= 5 ? "text-amber-600" : "text-zinc-400"}>
            ({remaining} restantes)
          </span>
        </span>
        <input
          value={slide.bodyText}
          maxLength={BODY_MAX}
          onChange={(event) => onChange({ bodyText: event.target.value })}
          className={fieldClass}
        />
      </label>

      <div className="grid grid-cols-2 gap-2">
        <label className="flex flex-col gap-1">
          <span className={labelClass}>Badge</span>
          <input
            value={slide.highlightTag ?? ""}
            onChange={(event) =>
              onChange({ highlightTag: event.target.value || undefined })
            }
            className={fieldClass}
          />
        </label>
        <label className="flex flex-col gap-1">
          <span className={labelClass}>Rodapé</span>
          <input
            value={slide.footerNote}
            onChange={(event) => onChange({ footerNote: event.target.value })}
            className={fieldClass}
          />
        </label>
      </div>

      <div className="flex flex-col gap-2">
        <span className={labelClass}>Imagem</span>
        <div className="flex gap-2">
          <input
            value={isUploaded ? "" : (slide.image?.url ?? "")}
            placeholder={isUploaded ? "arquivo local carregado" : "https://..."}
            onChange={(event) => setImageUrl(event.target.value)}
            className={fieldClass}
          />
          <label
            htmlFor={uploadId}
            title="Enviar arquivo local"
            className="flex shrink-0 cursor-pointer items-center rounded-md border border-zinc-200 bg-white px-2.5 text-zinc-600 transition hover:border-zinc-900"
          >
            <Upload size={14} />
          </label>
          <input
            id={uploadId}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(event) => handleUpload(event.target.files?.[0])}
          />
          {slide.image ? (
            <button
              type="button"
              title="Remover imagem"
              onClick={() => onChange({ image: undefined })}
              className="flex shrink-0 items-center rounded-md border border-zinc-200 bg-white px-2.5 text-zinc-600 transition hover:border-red-500 hover:text-red-600"
            >
              <X size={14} />
            </button>
          ) : null}
        </div>

        {slide.image ? (
          <div className="flex gap-1.5">
            {IMAGE_LAYOUTS.map(({ id, label }) => (
              <button
                key={id}
                type="button"
                onClick={() =>
                  slide.image && onChange({ image: { ...slide.image, layout: id } })
                }
                className={clsx(
                  "flex-1 rounded-md border px-2 py-1.5 text-[11px] font-medium transition",
                  slide.image?.layout === id
                    ? "border-zinc-900 bg-zinc-900 text-white"
                    : "border-zinc-200 text-zinc-600 hover:border-zinc-400",
                )}
              >
                {label}
              </button>
            ))}
          </div>
        ) : null}
      </div>

      {slide.type === "cta" ? (
        <label className="flex flex-col gap-1">
          <span className={labelClass}>URL do QR Code</span>
          <input
            value={slide.qrCodeUrl ?? ""}
            placeholder="https://sanwey.com.br/contato"
            onChange={(event) => onChange({ qrCodeUrl: event.target.value || undefined })}
            className={fieldClass}
          />
        </label>
      ) : null}
    </div>
  );
}
