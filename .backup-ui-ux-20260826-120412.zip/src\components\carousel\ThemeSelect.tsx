"use client";

import {
  slideThemes,
  THEME_GROUPS,
  type SlideThemeId,
} from "@/constants/themes";

type ThemeSelectProps = {
  value: SlideThemeId;
  onChange: (themeId: SlideThemeId) => void;
};

export function ThemeSelect({ value, onChange }: ThemeSelectProps) {
  const theme = slideThemes[value];

  return (
    <div className="flex items-center gap-2">
      {/* Amostra do tema: o dropdown sozinho não mostra a paleta. */}
      <span
        aria-hidden
        className="flex h-9 w-9 shrink-0 items-end justify-center rounded-md border border-zinc-300 p-1"
        style={{ background: theme.background }}
      >
        <span
          className="block h-1.5 w-5 rounded-full"
          style={{ background: theme.accent }}
        />
      </span>
      <select
        value={value}
        onChange={(event) => onChange(event.target.value as SlideThemeId)}
        aria-label="Tema do carrossel"
        className="w-full rounded-md border border-zinc-200 bg-white px-2.5 py-2 text-sm text-zinc-900 outline-none focus:border-zinc-900"
      >
        {THEME_GROUPS.map((group) => (
          <optgroup key={group.label} label={group.label}>
            {group.themes.map((themeId) => (
              <option key={themeId} value={themeId}>
                {slideThemes[themeId].label}
              </option>
            ))}
          </optgroup>
        ))}
      </select>
    </div>
  );
}
