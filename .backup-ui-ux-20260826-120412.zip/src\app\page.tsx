"use client";

import clsx from "clsx";
import { FileDown, Images, Loader2, Plus, Sparkles, Upload, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";

import { CarouselPreview } from "@/components/carousel/CarouselPreview";
import { CarouselSlide, type LogoConfig } from "@/components/carousel/CarouselSlide";
import { SlideFields } from "@/components/carousel/SlideFields";
import { ThemeSelect } from "@/components/carousel/ThemeSelect";
import { brandOptions, brands, type BrandId } from "@/constants/brands";
import type { SlideThemeId } from "@/constants/themes";
import { exportToPDF, exportToZip } from "@/lib/export";
import { MAX_SLIDES, MIN_SLIDES, type Carousel, type Slide } from "@/types/carousel";

/** A ordem do array é a verdade: slideNumber é sempre recalculado a partir dela. */
const renumber = (slides: Slide[]): Slide[] =>
  slides.map((slide, index) => ({ ...slide, slideNumber: index + 1 }));

/** Motivo pelo qual remover está bloqueado, ou undefined se pode remover. */
function removeBlockedReason(index: number, total: number) {
  if (total <= MIN_SLIDES) return `O mínimo é ${MIN_SLIDES} slides`;
  if (index === 0) return "A capa não pode ser removida";
  if (index === total - 1) return "O slide de CTA não pode ser removido";
  return undefined;
}

const slugify = (value: string) =>
  value
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "") || "carrossel";

const actionButton =
  "flex items-center gap-2 rounded-full border border-zinc-300 bg-white px-4 py-2 text-sm font-medium text-zinc-800 transition hover:border-zinc-900 disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:border-zinc-300";

const labelClass = "text-[11px] font-medium uppercase tracking-wide text-zinc-500";

const pillClass = (isActive: boolean) =>
  clsx(
    "rounded-full border px-3 py-1.5 text-xs font-medium transition",
    isActive
      ? "border-zinc-900 bg-zinc-900 text-white"
      : "border-zinc-200 text-zinc-700 hover:border-zinc-400",
  );

function readAsDataUrl(file: Blob) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("não foi possível ler o arquivo"));
    reader.readAsDataURL(file);
  });
}

/**
 * Embute o SVG como data URL antes do export. O html-to-image precisa inlinar
 * toda imagem do clone; se ele mesmo tiver que buscar o arquivo, o resultado
 * depende de timing de rede e o logo sai em branco. Com data URL não há busca.
 */
async function fetchAsDataUrl(url: string) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`logo não encontrado: ${url} (HTTP ${response.status})`);
  }
  return readAsDataUrl(await response.blob());
}

export default function Home() {
  const [input, setInput] = useState("");
  const [carousel, setCarousel] = useState<Carousel | null>(null);
  const [themeId, setThemeId] = useState<SlideThemeId>("dark-modern");
  const [brandId, setBrandId] = useState<BrandId | null>(null);
  const [customLogo, setCustomLogo] = useState<string | null>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [isGenerating, setIsGenerating] = useState(false);
  const [exporting, setExporting] = useState<"pdf" | "zip" | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Guarda a marca junto: assim um resultado de marca anterior nunca é usado,
  // sem precisar limpar o estado dentro do efeito.
  const [brandLogos, setBrandLogos] = useState<{
    brandId: BrandId;
    src: string;
    srcOnDark: string;
  } | null>(null);

  const exportRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    if (!brandId) return;

    let cancelled = false;
    const brand = brands[brandId];

    Promise.all([fetchAsDataUrl(brand.logoSrc), fetchAsDataUrl(brand.logoSrcOnDark)])
      .then(([src, srcOnDark]) => {
        if (!cancelled) setBrandLogos({ brandId, src, srcOnDark });
      })
      .catch((cause: unknown) => {
        if (!cancelled) {
          setError(cause instanceof Error ? cause.message : "falha ao carregar o logo");
        }
      });

    return () => {
      cancelled = true;
    };
  }, [brandId]);

  // Logo customizado vence a marca; sem versão invertida, usa o mesmo arquivo.
  const logo: LogoConfig | null = customLogo
    ? { src: customLogo, alt: "Logo", policy: "all" }
    : brandId && brandLogos?.brandId === brandId
      ? {
          src: brandLogos.src,
          srcOnDark: brandLogos.srcOnDark,
          alt: brands[brandId].label,
          policy: brands[brandId].logoPolicy,
        }
      : null;

  function selectBrand(id: BrandId | null) {
    setBrandId(id);
    if (id) setThemeId(brands[id].themeId);
  }

  async function generate() {
    setIsGenerating(true);
    setError(null);

    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ input }),
      });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.issues?.join(" - ") ?? data.error ?? "falha ao gerar o carrossel",
        );
      }

      setCarousel(data as Carousel);
      setActiveIndex(0);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "falha ao gerar o carrossel");
    } finally {
      setIsGenerating(false);
    }
  }

  function updateSlide(index: number, patch: Partial<Slide>) {
    setCarousel((current) =>
      current
        ? {
            ...current,
            slides: current.slides.map((slide, slideIndex) =>
              slideIndex === index ? { ...slide, ...patch } : slide,
            ),
          }
        : current,
    );
  }

  /** Toda mutação estrutural passa por aqui, então a paginação nunca dessincroniza. */
  function mutateSlides(mutate: (slides: Slide[]) => Slide[]) {
    setCarousel((current) =>
      current ? { ...current, slides: renumber(mutate(current.slides)) } : current,
    );
  }

  function addSlide() {
    if (!carousel || carousel.slides.length >= MAX_SLIDES) return;

    mutateSlides((slides) => {
      const blank: Slide = {
        slideNumber: 0,
        type: "content",
        headline: "Nova headline",
        bodyText: "Texto de apoio",
        footerNote: slides[0]?.footerNote ?? "",
      };
      // Entra antes do CTA, que o schema exige como último slide.
      return [...slides.slice(0, -1), blank, slides[slides.length - 1]];
    });
    setActiveIndex(carousel.slides.length - 1);
  }

  function duplicateSlide(index: number) {
    if (!carousel || carousel.slides.length >= MAX_SLIDES) return;

    mutateSlides((slides) => [
      ...slides.slice(0, index + 1),
      { ...slides[index] },
      ...slides.slice(index + 1),
    ]);
    setActiveIndex(index + 1);
  }

  function removeSlide(index: number) {
    if (!carousel || removeBlockedReason(index, carousel.slides.length)) return;

    mutateSlides((slides) => slides.filter((_, slideIndex) => slideIndex !== index));
    setActiveIndex((current) =>
      Math.max(0, Math.min(current, carousel.slides.length - 2)),
    );
  }

  async function runExport(kind: "pdf" | "zip") {
    if (!carousel) return;

    const nodes = exportRefs.current
      .slice(0, carousel.slides.length)
      .filter((node): node is HTMLDivElement => node !== null);
    if (nodes.length === 0) return;

    setExporting(kind);
    setError(null);

    try {
      const name = slugify(carousel.title);
      if (kind === "pdf") {
        await exportToPDF(nodes, name);
      } else {
        await exportToZip(nodes, name);
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "falha ao exportar");
    } finally {
      setExporting(null);
    }
  }

  return (
    <div className="flex flex-1 flex-col overflow-hidden bg-zinc-100 font-sans">
      <header className="flex shrink-0 items-center justify-between gap-4 border-b border-zinc-200 bg-white px-6 py-3">
        <div className="min-w-0">
          <h1 className="text-sm font-semibold text-zinc-900">Carousel Builder</h1>
          <p className="truncate text-xs text-zinc-500">
            {carousel?.title ?? "Gere um carrossel B2B a partir de uma URL ou tema"}
          </p>
        </div>
        <div className="flex shrink-0 gap-2">
          <button
            type="button"
            className={actionButton}
            onClick={() => runExport("pdf")}
            disabled={!carousel || exporting !== null}
          >
            {exporting === "pdf" ? (
              <Loader2 size={16} className="animate-spin" />
            ) : (
              <FileDown size={16} />
            )}
            Exportar PDF
          </button>
          <button
            type="button"
            className={actionButton}
            onClick={() => runExport("zip")}
            disabled={!carousel || exporting !== null}
          >
            {exporting === "zip" ? (
              <Loader2 size={16} className="animate-spin" />
            ) : (
              <Images size={16} />
            )}
            Baixar Imagens (ZIP)
          </button>
        </div>
      </header>

      <div className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-[minmax(0,420px)_minmax(0,1fr)]">
        <aside className="flex min-h-0 flex-col gap-6 overflow-y-auto border-r border-zinc-200 bg-white p-6">
          <div className="flex flex-col gap-2">
            <span className={labelClass}>Tema visual</span>
            <ThemeSelect value={themeId} onChange={setThemeId} />
          </div>

          <div className="flex flex-col gap-2">
            <label htmlFor="brief" className={labelClass}>
              URL ou tema
            </label>
            <input
              id="brief"
              value={input}
              onChange={(event) => setInput(event.target.value)}
              placeholder="https://... ou: reduzir custo logístico na indústria"
              className="w-full rounded-md border border-zinc-200 px-3 py-2 text-sm outline-none focus:border-zinc-900"
            />
            <button
              type="button"
              onClick={generate}
              disabled={isGenerating || input.trim().length < 3}
              className="flex items-center justify-center gap-2 rounded-md bg-zinc-900 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-zinc-800 disabled:cursor-not-allowed disabled:opacity-40"
            >
              {isGenerating ? (
                <>
                  <Loader2 size={16} className="animate-spin" />
                  Gerando carrossel...
                </>
              ) : (
                <>
                  <Sparkles size={16} />
                  Gerar carrossel
                </>
              )}
            </button>
            {error ? (
              <p className="rounded-md bg-red-50 px-3 py-2 text-xs text-red-700">{error}</p>
            ) : null}
          </div>

          <div className="flex flex-col gap-2">
            <span className={labelClass}>Marca</span>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => selectBrand(null)}
                className={pillClass(brandId === null)}
              >
                Nenhuma
              </button>
              {brandOptions.map(({ id, label }) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => selectBrand(id)}
                  className={pillClass(brandId === id)}
                >
                  {label}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <label className="flex cursor-pointer items-center gap-2 rounded-md border border-zinc-200 px-3 py-1.5 text-xs text-zinc-700 transition hover:border-zinc-900">
                <Upload size={13} />
                {customLogo ? "Trocar logo" : "Logo customizado"}
                <input
                  type="file"
                  accept="image/png,image/svg+xml"
                  className="hidden"
                  onChange={async (event) => {
                    const file = event.target.files?.[0];
                    if (file) setCustomLogo(await readAsDataUrl(file));
                  }}
                />
              </label>
              {customLogo ? (
                <button
                  type="button"
                  onClick={() => setCustomLogo(null)}
                  title="Remover logo customizado"
                  className="flex items-center rounded-md border border-zinc-200 px-2 py-1.5 text-zinc-600 transition hover:border-red-500 hover:text-red-600"
                >
                  <X size={13} />
                </button>
              ) : null}
            </div>
          </div>

          {carousel ? (
            <div className="flex flex-col gap-3">
              <span className={labelClass}>
                Texto dos slides ({carousel.slides.length}/{MAX_SLIDES})
              </span>
              {carousel.slides.map((slide, index) => {
                const blocked = removeBlockedReason(index, carousel.slides.length);
                return (
                  <SlideFields
                    key={index}
                    slide={slide}
                    isActive={index === activeIndex}
                    onChange={(patch) => updateSlide(index, patch)}
                    onFocus={() => setActiveIndex(index)}
                    onDuplicate={() => duplicateSlide(index)}
                    onRemove={() => removeSlide(index)}
                    canRemove={blocked === undefined}
                    removeBlockedReason={blocked}
                  />
                );
              })}
              <button
                type="button"
                onClick={addSlide}
                disabled={carousel.slides.length >= MAX_SLIDES}
                className="flex items-center justify-center gap-2 rounded-lg border border-dashed border-zinc-300 py-2.5 text-xs font-medium text-zinc-600 transition hover:border-zinc-900 hover:text-zinc-900 disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:border-zinc-300 disabled:hover:text-zinc-600"
              >
                <Plus size={14} />
                {carousel.slides.length >= MAX_SLIDES
                  ? `Máximo de ${MAX_SLIDES} slides`
                  : "Adicionar slide"}
              </button>
            </div>
          ) : null}
        </aside>

        <section className="min-h-0 overflow-y-auto p-6">
          {carousel ? (
            <CarouselPreview
              slides={carousel.slides}
              themeId={themeId}
              logo={logo}
              activeIndex={activeIndex}
              onActiveIndexChange={setActiveIndex}
            />
          ) : (
            <div className="flex h-full items-center justify-center rounded-lg border border-dashed border-zinc-300 text-sm text-zinc-500">
              O preview aparece aqui depois da geração.
            </div>
          )}
        </section>
      </div>

      {/* Palco oculto em escala 1:1 — é daqui que o export tira os 1080x1350. */}
      {carousel ? (
        <div aria-hidden className="pointer-events-none fixed left-[-10000px] top-0">
          {carousel.slides.map((slide, index) => (
            <div
              key={index}
              ref={(node) => {
                exportRefs.current[index] = node;
              }}
            >
              <CarouselSlide
                slide={slide}
                totalSlides={carousel.slides.length}
                themeId={themeId}
                logo={logo}
                scale={1}
              />
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}
